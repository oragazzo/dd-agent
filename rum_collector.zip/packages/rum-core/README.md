# `rum-core`

Datadog browser RUM core utilities.
