import { Configuration } from '@datadog/browser-core';
import { RumFetchCompleteContext, RumFetchStartContext, RumXhrCompleteContext, RumXhrStartContext } from '../requestCollection';
export interface Tracer {
    traceFetch: (context: Partial<RumFetchStartContext>) => void;
    traceXhr: (context: Partial<RumXhrStartContext>, xhr: XMLHttpRequest) => void;
    clearTracingIfCancelled: (context: RumFetchCompleteContext | RumXhrCompleteContext) => void;
}
export declare function clearTracingIfCancelled(context: RumFetchCompleteContext | RumXhrCompleteContext): void;
export declare function startTracer(configuration: Configuration): Tracer;
export declare function isTracingSupported(): boolean;
export declare class TraceIdentifier {
    private buffer;
    constructor();
    toString(radix: number): string;
    /**
     * Format used everywhere except the trace intake
     */
    toDecimalString(): string;
    private readInt32;
}
