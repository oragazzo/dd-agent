import { LifeCycle } from '../../lifeCycle';
export declare function startLongTaskCollection(lifeCycle: LifeCycle): void;
