import { NewLocationListener } from '../../../boot/rum';
import { LifeCycle } from '../../lifeCycle';
export declare function startViewCollection(lifeCycle: LifeCycle, location: Location, onNewLocation?: NewLocationListener): {
    addTiming: (name: string, time?: import("@datadog/browser-core").RelativeTime) => void;
    stop: () => void;
};
