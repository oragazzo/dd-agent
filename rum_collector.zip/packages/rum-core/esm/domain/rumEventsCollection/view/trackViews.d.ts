import { Duration, RelativeTime } from '@datadog/browser-core';
import { NewLocationListener } from '../../../boot/rum';
import { LifeCycle } from '../../lifeCycle';
import { EventCounts } from '../../trackEventCounts';
import { ViewLoadingType, ViewCustomTimings } from '../../../rawRumEvent.types';
import { Timings } from './trackTimings';
export interface View {
    id: string;
    name?: string;
    location: Location;
    referrer: string;
    timings: Timings;
    customTimings: ViewCustomTimings;
    eventCounts: EventCounts;
    documentVersion: number;
    startTime: RelativeTime;
    duration: Duration;
    isActive: boolean;
    loadingTime?: Duration;
    loadingType: ViewLoadingType;
    cumulativeLayoutShift?: number;
}
export interface ViewCreatedEvent {
    id: string;
    name?: string;
    location: Location;
    referrer: string;
    startTime: RelativeTime;
}
export declare const THROTTLE_VIEW_UPDATE_PERIOD = 3000;
export declare const SESSION_KEEP_ALIVE_INTERVAL: number;
export declare function trackViews(location: Location, lifeCycle: LifeCycle, onNewLocation?: NewLocationListener): {
    addTiming: (name: string, time?: RelativeTime) => void;
    stop: () => void;
};
