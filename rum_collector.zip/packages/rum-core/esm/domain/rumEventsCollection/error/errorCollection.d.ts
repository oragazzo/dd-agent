import { Configuration, Context, Observable, RawError, RelativeTime } from '@datadog/browser-core';
import { CommonContext } from '../../../rawRumEvent.types';
import { LifeCycle } from '../../lifeCycle';
export interface ProvidedError {
    startTime: RelativeTime;
    error: unknown;
    context?: Context;
    source: ProvidedSource;
}
export declare type ProvidedSource = 'custom' | 'network' | 'source';
export declare function startErrorCollection(lifeCycle: LifeCycle, configuration: Configuration): {
    addError: ({ error, startTime, context: customerContext, source }: ProvidedError, savedCommonContext?: CommonContext | undefined) => void;
};
export declare function doStartErrorCollection(lifeCycle: LifeCycle, observable: Observable<RawError>): {
    addError: ({ error, startTime, context: customerContext, source }: ProvidedError, savedCommonContext?: CommonContext | undefined) => void;
};
