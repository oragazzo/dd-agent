export declare function getActionNameFromElement(element: Element): string;
