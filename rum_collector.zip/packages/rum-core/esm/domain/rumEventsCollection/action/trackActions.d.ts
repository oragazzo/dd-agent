import { Context, Duration, RelativeTime } from '@datadog/browser-core';
import { LifeCycle } from '../../lifeCycle';
import { ActionType } from '../../../rawRumEvent.types';
declare type AutoActionType = ActionType.CLICK;
export interface ActionCounts {
    errorCount: number;
    longTaskCount: number;
    resourceCount: number;
}
export interface CustomAction {
    type: ActionType.CUSTOM;
    name: string;
    startTime: RelativeTime;
    context?: Context;
}
export interface AutoAction {
    type: AutoActionType;
    id: string;
    name: string;
    startTime: RelativeTime;
    duration: Duration;
    counts: ActionCounts;
}
export interface AutoActionCreatedEvent {
    id: string;
    startTime: RelativeTime;
}
export declare function trackActions(lifeCycle: LifeCycle): {
    stop(): void;
};
export {};
