import { Configuration } from '@datadog/browser-core';
import { CommonContext } from '../../../rawRumEvent.types';
import { LifeCycle } from '../../lifeCycle';
import { CustomAction } from './trackActions';
export declare function startActionCollection(lifeCycle: LifeCycle, configuration: Configuration): {
    addAction: (action: CustomAction, savedCommonContext?: CommonContext | undefined) => void;
};
