import { LifeCycle } from '../../lifeCycle';
import { RumSession } from '../../rumSession';
export declare function startResourceCollection(lifeCycle: LifeCycle, session: RumSession): void;
