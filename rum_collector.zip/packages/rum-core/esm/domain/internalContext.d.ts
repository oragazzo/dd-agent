import { InternalContext } from '../rawRumEvent.types';
import { ParentContexts } from './parentContexts';
import { RumSession } from './rumSession';
/**
 * Internal context keep returning v1 format
 * to not break compatibility with logs data format
 */
export declare function startInternalContext(applicationId: string, session: RumSession, parentContexts: ParentContexts): {
    get: (startTime?: number | undefined) => InternalContext | undefined;
};
