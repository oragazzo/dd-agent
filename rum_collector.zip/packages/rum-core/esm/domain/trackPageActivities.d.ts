import { Observable, RelativeTime } from '@datadog/browser-core';
import { LifeCycle } from './lifeCycle';
export declare const PAGE_ACTIVITY_VALIDATION_DELAY = 100;
export declare const PAGE_ACTIVITY_END_DELAY = 100;
export declare const PAGE_ACTIVITY_MAX_DURATION = 10000;
export interface PageActivityEvent {
    isBusy: boolean;
}
export declare function waitIdlePageActivity(lifeCycle: LifeCycle, completionCallback: (hadActivity: boolean, endTime: RelativeTime) => void): {
    stop: () => void;
};
export declare function trackPageActivities(lifeCycle: LifeCycle): {
    observable: Observable<PageActivityEvent>;
    stop: () => void;
};
export declare function waitPageActivitiesCompletion(pageActivitiesObservable: Observable<PageActivityEvent>, stopPageActivitiesTracking: () => void, completionCallback: (hadActivity: boolean, endTime: RelativeTime) => void): {
    stop: () => void;
};
