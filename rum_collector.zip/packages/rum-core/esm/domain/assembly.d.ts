import { Configuration } from '@datadog/browser-core';
import { CommonContext } from '../rawRumEvent.types';
import { LifeCycle } from './lifeCycle';
import { ParentContexts } from './parentContexts';
import { RumSession } from './rumSession';
export declare function startRumAssembly(applicationId: string, configuration: Configuration, lifeCycle: LifeCycle, session: RumSession, parentContexts: ParentContexts, getCommonContext: () => CommonContext): void;
