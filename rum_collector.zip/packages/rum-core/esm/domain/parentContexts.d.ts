import { RelativeTime } from '@datadog/browser-core';
import { ActionContext, ViewContext } from '../rawRumEvent.types';
import { LifeCycle } from './lifeCycle';
import { RumSession } from './rumSession';
export declare const VIEW_CONTEXT_TIME_OUT_DELAY: number;
export declare const ACTION_CONTEXT_TIME_OUT_DELAY: number;
export declare const CLEAR_OLD_CONTEXTS_INTERVAL: number;
export interface ParentContexts {
    findAction: (startTime?: RelativeTime) => ActionContext | undefined;
    findView: (startTime?: RelativeTime) => ViewContext | undefined;
    stop: () => void;
}
export declare function startParentContexts(lifeCycle: LifeCycle, session: RumSession): ParentContexts;
