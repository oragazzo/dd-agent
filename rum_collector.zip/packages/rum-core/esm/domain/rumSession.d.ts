import { Configuration } from '@datadog/browser-core';
import { LifeCycle } from './lifeCycle';
export declare const RUM_SESSION_KEY = "rum";
export interface RumSession {
    getId: () => string | undefined;
    isTracked: () => boolean;
    isTrackedWithResource: () => boolean;
}
export declare enum RumTrackingType {
    NOT_TRACKED = "0",
    TRACKED_WITH_RESOURCES = "1",
    TRACKED_WITHOUT_RESOURCES = "2"
}
export declare function startRumSession(configuration: Configuration, lifeCycle: LifeCycle): RumSession;
