import { Configuration, Duration, FetchCompleteContext, FetchStartContext, RelativeTime, RequestType, XhrCompleteContext, XhrStartContext } from '@datadog/browser-core';
import { LifeCycle } from './lifeCycle';
import { TraceIdentifier, Tracer } from './tracing/tracer';
export interface CustomContext {
    requestIndex: number;
    spanId?: TraceIdentifier;
    traceId?: TraceIdentifier;
}
export interface RumFetchStartContext extends FetchStartContext, CustomContext {
}
export interface RumFetchCompleteContext extends FetchCompleteContext, CustomContext {
}
export interface RumXhrStartContext extends XhrStartContext, CustomContext {
}
export interface RumXhrCompleteContext extends XhrCompleteContext, CustomContext {
}
export interface RequestStartEvent {
    requestIndex: number;
}
export interface RequestCompleteEvent {
    requestIndex: number;
    type: RequestType;
    method: string;
    url: string;
    status: number;
    response?: string;
    responseType?: string;
    startTime: RelativeTime;
    duration: Duration;
    spanId?: TraceIdentifier;
    traceId?: TraceIdentifier;
}
export declare function startRequestCollection(lifeCycle: LifeCycle, configuration: Configuration): void;
export declare function trackXhr(lifeCycle: LifeCycle, configuration: Configuration, tracer: Tracer): import("@datadog/browser-core").XhrProxy<RumXhrStartContext, RumXhrCompleteContext>;
export declare function trackFetch(lifeCycle: LifeCycle, configuration: Configuration, tracer: Tracer): import("@datadog/browser-core").FetchProxy<RumFetchStartContext, RumFetchCompleteContext>;
