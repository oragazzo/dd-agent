import { LifeCycle } from '../domain/lifeCycle';
export declare function startDOMMutationCollection(lifeCycle: LifeCycle): {
    stop(): void;
};
