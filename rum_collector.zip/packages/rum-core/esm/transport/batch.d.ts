import { Configuration } from '@datadog/browser-core';
import { LifeCycle } from '../domain/lifeCycle';
export declare function startRumBatch(configuration: Configuration, lifeCycle: LifeCycle): {
    stop(): void;
};
