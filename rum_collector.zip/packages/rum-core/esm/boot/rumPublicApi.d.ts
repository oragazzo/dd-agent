import { Context, UserConfiguration } from '@datadog/browser-core';
import { ProvidedSource } from '../domain/rumEventsCollection/error/errorCollection';
import { User } from '../rawRumEvent.types';
import { RumEvent } from '../rumEvent.types';
import { startRum } from './rum';
export interface RumUserConfiguration extends UserConfiguration {
    applicationId: string;
    beforeSend?: (event: RumEvent) => void | boolean;
}
export declare type RumPublicApi = ReturnType<typeof makeRumPublicApi>;
export declare type StartRum = typeof startRum;
export declare function makeRumPublicApi(startRumImpl: StartRum): {
    init: (userConfiguration: RumUserConfiguration) => void;
    addRumGlobalContext: (key: string, value: any) => void;
    removeRumGlobalContext: (key: string) => void;
    getRumGlobalContext: () => Context;
    setRumGlobalContext: (newContext: object) => void;
    getInternalContext: (startTime?: number | undefined) => import("../rawRumEvent.types").InternalContext | undefined;
    addAction: (name: string, context?: object | undefined) => void;
    /**
     * @deprecated use addAction instead
     */
    addUserAction: (name: string, context?: object | undefined) => void;
    addError: (error: unknown, context?: object | undefined, source?: ProvidedSource) => void;
    addTiming: (name: string) => void;
    setUser: (newUser: User) => void;
} & {
    onReady(callback: () => void): void;
};
