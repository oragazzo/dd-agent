import { Configuration } from '@datadog/browser-core';
import { LifeCycle } from '../domain/lifeCycle';
import { RumSession } from '../domain/rumSession';
import { CommonContext } from '../rawRumEvent.types';
import { RumUserConfiguration } from './rumPublicApi';
export declare type NewLocationListener = (newLocation: Location, oldLocation?: Location) => undefined | {
    shouldCreateView?: boolean;
    viewName?: string;
};
export declare function startRum(userConfiguration: RumUserConfiguration & {
    onNewLocation?: NewLocationListener;
}, getCommonContext: () => CommonContext): {
    addAction: (action: import("../domain/rumEventsCollection/action/trackActions").CustomAction, savedCommonContext?: CommonContext | undefined) => void;
    addError: ({ error, startTime, context: customerContext, source }: import("../domain/rumEventsCollection/error/errorCollection").ProvidedError, savedCommonContext?: CommonContext | undefined) => void;
    addTiming: (name: string, time?: import("@datadog/browser-core").RelativeTime) => void;
    configuration: Configuration;
    lifeCycle: LifeCycle;
    parentContexts: import("../domain/parentContexts").ParentContexts;
    session: RumSession;
    getInternalContext: (startTime?: number | undefined) => import("../rawRumEvent.types").InternalContext | undefined;
};
export declare function startRumEventCollection(applicationId: string, location: Location, lifeCycle: LifeCycle, configuration: Configuration, session: RumSession, getCommonContext: () => CommonContext, onNewLocation?: NewLocationListener): {
    addAction: (action: import("../domain/rumEventsCollection/action/trackActions").CustomAction, savedCommonContext?: CommonContext | undefined) => void;
    addError: ({ error, startTime, context: customerContext, source }: import("../domain/rumEventsCollection/error/errorCollection").ProvidedError, savedCommonContext?: CommonContext | undefined) => void;
    parentContexts: import("../domain/parentContexts").ParentContexts;
    addTiming: (name: string, time?: import("@datadog/browser-core").RelativeTime) => void;
    stop(): void;
};
