export declare const datadogRum: {
    init: (userConfiguration: import("@datadog/browser-rum-core").RumUserConfiguration) => void;
    addRumGlobalContext: (key: string, value: any) => void;
    removeRumGlobalContext: (key: string) => void;
    getRumGlobalContext: () => import("@datadog/browser-core").Context;
    setRumGlobalContext: (newContext: object) => void;
    getInternalContext: (startTime?: number | undefined) => import("@datadog/browser-rum-core/cjs/rawRumEvent.types").InternalContext | undefined;
    addAction: (name: string, context?: object | undefined) => void;
    addUserAction: (name: string, context?: object | undefined) => void;
    addError: (error: unknown, context?: object | undefined, source?: "custom" | "network" | "source" | undefined) => void;
    addTiming: (name: string) => void;
    setUser: (newUser: import("@datadog/browser-rum-core/cjs/rawRumEvent.types").User) => void;
} & {
    onReady(callback: () => void): void;
};
