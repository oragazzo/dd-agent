import { BuildEnv } from '@datadog/browser-core';
export declare const buildEnv: BuildEnv;
