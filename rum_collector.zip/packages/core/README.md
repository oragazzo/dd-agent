# `core`

Datadog browser core utilities.
