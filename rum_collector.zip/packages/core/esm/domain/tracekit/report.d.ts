import { Handler } from './types';
/**
 * Cross-browser processing of unhandled exceptions
 *
 * Syntax:
 * ```js
 *   subscribe(function(stackInfo) { ... })
 *   unsubscribe(function(stackInfo) { ... })
 *   report(exception)
 *   try { ...code... } catch(ex) { report(ex); }
 * ```
 *
 * Supports:
 *   - Firefox: full stack trace with line numbers, plus column number
 *     on top frame; column number is not guaranteed
 *   - Opera: full stack trace with line and column numbers
 *   - Chrome: full stack trace with line and column numbers
 *   - Safari: line and column number for the top frame only; some frames
 *     may be missing, and column number is not guaranteed
 *   - IE: line and column number for the top frame only; some frames
 *     may be missing, and column number is not guaranteed
 *
 * In theory, TraceKit should work on all of the following versions:
 *   - IE5.5+ (only 8.0 tested)
 *   - Firefox 0.9+ (only 3.5+ tested)
 *   - Opera 7+ (only 10.50 tested; versions 9 and earlier may require
 *     Exceptions Have Stacktrace to be enabled in opera:config)
 *   - Safari 3+ (only 4+ tested)
 *   - Chrome 1+ (only 5+ tested)
 *   - Konqueror 3.5+ (untested)
 *
 * Requires computeStackTrace.
 *
 * Tries to catch all unhandled exceptions and report them to the
 * subscribed handlers. Please note that report will rethrow the
 * exception. This is REQUIRED in order to get a useful stack trace in IE.
 * If the exception does not reach the top of the browser, you will only
 * get a stack trace from the point where report was called.
 *
 * Handlers receive a StackTrace object as described in the
 * computeStackTrace docs.
 *
 * @memberof TraceKit
 * @namespace
 */
/**
 * Reports an unhandled Error.
 * @param {Error} ex
 * @memberof report
 * @throws An exception if an incomplete stack trace is detected (old IE browsers).
 */
export declare function report(ex: Error): void;
/**
 * Add a crash handler.
 * @param {Function} handler
 * @memberof report
 */
export declare function subscribe(handler: Handler): void;
/**
 * Remove a crash handler.
 * @param {Function} handler
 * @memberof report
 */
export declare function unsubscribe(handler: Handler): void;
/**
 * Ensures all global unhandled exceptions are recorded.
 * Supported by Gecko and IE.
 * @param {Event|string} message Error message.
 * @param {string=} url URL of script that generated the exception.
 * @param {(number|string)=} lineNo The line number at which the error occurred.
 * @param {(number|string)=} columnNo The column number at which the error occurred.
 * @param {Error=} errorObj The actual Error object.
 * @memberof report
 */
export declare function traceKitWindowOnError(this: any, message: Event | string, url?: string, lineNo?: number, columnNo?: number, errorObj?: Error): any;
