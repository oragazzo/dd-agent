import { BuildEnv } from '../boot/init';
import { TransportConfiguration, UserConfiguration } from './configuration';
export declare const Datacenter: {
    readonly EU: "eu";
    readonly US: "us";
};
export declare type Datacenter = typeof Datacenter[keyof typeof Datacenter];
export declare const INTAKE_SITE: {
    eu: string;
    us: string;
};
export declare function computeTransportConfiguration(userConfiguration: UserConfiguration, buildEnv: BuildEnv): TransportConfiguration;
