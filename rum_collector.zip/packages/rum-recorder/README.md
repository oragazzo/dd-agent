# RUM Browser Monitoring and Session Recording

## Overview

This package is equivalent to the [RUM package](../rum), but will record the user session beside
collecting Real User Monitoring data.

## Setup

See the [RUM package](../rum/README.md) documentation.
