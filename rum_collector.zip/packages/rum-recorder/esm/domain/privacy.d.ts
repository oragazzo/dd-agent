export declare function nodeShouldBeHidden(node: Node): boolean;
export declare function nodeOrAncestorsShouldBeHidden(node: Node | null): boolean;
export declare function nodeShouldHaveInputIgnored(node: Node): boolean;
export declare function nodeOrAncestorsShouldHaveInputIgnored(node: Node | null): boolean;
