import { SegmentMeta } from '../types';
import { DeflateWorker } from './deflateWorker';
import { SegmentWriter } from './segment';
export declare class DeflateSegmentWriter implements SegmentWriter {
    private worker;
    private onWrote;
    private onFlushed;
    private nextId;
    private pendingMeta;
    constructor(worker: DeflateWorker, onWrote: (size: number) => void, onFlushed: (data: Uint8Array, meta: SegmentMeta) => void);
    write(data: string): void;
    flush(data: string | undefined, meta: SegmentMeta): void;
}
