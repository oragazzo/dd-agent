import { RecordAPI, RecordOptions } from './types';
export declare function record(options?: RecordOptions): RecordAPI;
