import { ListenerHandler, ObserverParam } from './types';
export declare const INPUT_TAGS: string[];
export declare function initObservers(o: ObserverParam): ListenerHandler;
