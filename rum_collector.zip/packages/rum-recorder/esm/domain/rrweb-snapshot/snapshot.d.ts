import { SerializedNodeWithId, INode, IdNodeMap } from './types';
export declare const IGNORED_NODE = -2;
export declare function cleanupSnapshot(): void;
export declare function absoluteToStylesheet(cssText: string | null, href: string): string;
export declare function absoluteToDoc(doc: Document, attributeValue: string): string;
export declare function transformAttribute(doc: Document, name: string, value: string): string;
export declare function serializeNodeWithId(n: Node | INode, options: {
    doc: Document;
    map: IdNodeMap;
    skipChild: boolean;
    preserveWhiteSpace?: boolean;
}): SerializedNodeWithId | null;
export declare function snapshot(n: Document): [SerializedNodeWithId | null, IdNodeMap];
