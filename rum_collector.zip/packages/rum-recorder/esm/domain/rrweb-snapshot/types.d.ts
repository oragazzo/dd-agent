export declare enum NodeType {
    Document = 0,
    DocumentType = 1,
    Element = 2,
    Text = 3,
    CDATA = 4,
    Comment = 5
}
export declare type DocumentNode = {
    type: NodeType.Document;
    childNodes: SerializedNodeWithId[];
};
export declare type DocumentTypeNode = {
    type: NodeType.DocumentType;
    name: string;
    publicId: string;
    systemId: string;
};
export declare type Attributes = {
    [key: string]: string | number | boolean;
};
export declare type ElementNode = {
    type: NodeType.Element;
    tagName: string;
    attributes: Attributes;
    childNodes: SerializedNodeWithId[];
    isSVG?: true;
    shouldBeHidden?: boolean;
};
export declare type TextNode = {
    type: NodeType.Text;
    textContent: string;
    isStyle?: true;
};
export declare type CDataNode = {
    type: NodeType.CDATA;
    textContent: '';
};
export declare type CommentNode = {
    type: NodeType.Comment;
    textContent: string;
};
export declare type SerializedNode = DocumentNode | DocumentTypeNode | ElementNode | TextNode | CDataNode | CommentNode;
export declare type SerializedNodeWithId = SerializedNode & {
    id: number;
};
export interface INode extends Node {
    __sn: SerializedNodeWithId;
}
export declare type IdNodeMap = {
    [key: number]: INode;
};
