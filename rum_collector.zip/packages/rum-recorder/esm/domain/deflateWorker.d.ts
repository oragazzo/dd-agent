export function createDeflateWorker(): Worker;
