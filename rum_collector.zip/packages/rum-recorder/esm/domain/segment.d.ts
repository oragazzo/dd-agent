import { CreationReason, Record, SegmentContext, SegmentMeta } from '../types';
export interface SegmentWriter {
    write(data: string): void;
    flush(data: string, meta: SegmentMeta): void;
}
export declare class Segment {
    private writer;
    readonly context: SegmentContext;
    private creationReason;
    private start;
    private end;
    private recordsCount;
    private hasFullSnapshot;
    private lastRecordType;
    constructor(writer: SegmentWriter, context: SegmentContext, creationReason: CreationReason, initialRecord: Record);
    addRecord(record: Record): void;
    flush(): void;
}
