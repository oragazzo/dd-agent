import { SegmentMeta } from '../types';
export declare const SEND_BEACON_BYTE_LENGTH_LIMIT = 60000;
export declare function send(endpointUrl: string, data: Uint8Array, meta: SegmentMeta): void;
export declare function toFormEntries(input: object, onEntry: (key: string, value: string) => void, prefix?: string): void;
