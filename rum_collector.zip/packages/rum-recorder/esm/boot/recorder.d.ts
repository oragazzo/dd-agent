import { Configuration } from '@datadog/browser-core';
import { LifeCycle, ParentContexts, RumSession } from '@datadog/browser-rum-core';
import { RawRecord } from '../types';
export declare function startRecording(lifeCycle: LifeCycle, applicationId: string, configuration: Configuration, session: RumSession, parentContexts: ParentContexts): {
    stop(): void;
};
export declare function trackFocusRecords(lifeCycle: LifeCycle, addRawRecord: (record: RawRecord) => void): {
    stop: () => void;
};
export declare function trackViewEndRecord(lifeCycle: LifeCycle, addRawRecord: (record: RawRecord) => void): void;
